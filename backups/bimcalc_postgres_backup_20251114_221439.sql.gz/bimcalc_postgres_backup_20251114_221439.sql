--
-- PostgreSQL database dump
--

\restrict dpaxCSmugJdY0xRKd8dj6rb5UdJCj5lL0vyUKcBMfSQBx7xUTdAUAqHAVfRcf8U

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg12+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: data_sync_log; Type: TABLE; Schema: public; Owner: bimcalc
--

CREATE TABLE public.data_sync_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_timestamp timestamp with time zone NOT NULL,
    source_name text NOT NULL,
    status text NOT NULL,
    records_updated integer DEFAULT 0 NOT NULL,
    records_inserted integer DEFAULT 0 NOT NULL,
    records_failed integer DEFAULT 0 NOT NULL,
    message text,
    error_details jsonb,
    duration_seconds double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT data_sync_log_records_failed_check CHECK ((records_failed >= 0)),
    CONSTRAINT data_sync_log_records_inserted_check CHECK ((records_inserted >= 0)),
    CONSTRAINT data_sync_log_records_updated_check CHECK ((records_updated >= 0)),
    CONSTRAINT data_sync_log_status_check CHECK ((status = ANY (ARRAY['SUCCESS'::text, 'FAILED'::text, 'PARTIAL_SUCCESS'::text, 'SKIPPED'::text])))
);


ALTER TABLE public.data_sync_log OWNER TO bimcalc;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: bimcalc
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    doc_metadata json NOT NULL,
    doc_type text,
    source_file text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.documents OWNER TO bimcalc;

--
-- Name: item_mapping; Type: TABLE; Schema: public; Owner: bimcalc
--

CREATE TABLE public.item_mapping (
    id uuid NOT NULL,
    org_id text NOT NULL,
    canonical_key text NOT NULL,
    price_item_id uuid NOT NULL,
    start_ts timestamp with time zone DEFAULT now() NOT NULL,
    end_ts timestamp with time zone,
    created_by text NOT NULL,
    reason text NOT NULL,
    CONSTRAINT check_valid_period CHECK (((end_ts IS NULL) OR (end_ts > start_ts)))
);


ALTER TABLE public.item_mapping OWNER TO bimcalc;

--
-- Name: items; Type: TABLE; Schema: public; Owner: bimcalc
--

CREATE TABLE public.items (
    id uuid NOT NULL,
    org_id text NOT NULL,
    project_id text NOT NULL,
    classification_code integer,
    canonical_key text,
    category text,
    family text NOT NULL,
    type_name text NOT NULL,
    system_type text,
    omniclass_code integer,
    uniformat_code integer,
    quantity numeric(12,2),
    unit text,
    width_mm double precision,
    height_mm double precision,
    dn_mm double precision,
    angle_deg double precision,
    material text,
    source_file text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.items OWNER TO bimcalc;

--
-- Name: match_flags; Type: TABLE; Schema: public; Owner: bimcalc
--

CREATE TABLE public.match_flags (
    id uuid NOT NULL,
    match_result_id uuid NOT NULL,
    item_id uuid NOT NULL,
    price_item_id uuid NOT NULL,
    flag_type text NOT NULL,
    severity text NOT NULL,
    message text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_severity_valid CHECK ((severity = ANY (ARRAY['Critical-Veto'::text, 'Advisory'::text])))
);


ALTER TABLE public.match_flags OWNER TO bimcalc;

--
-- Name: match_results; Type: TABLE; Schema: public; Owner: bimcalc
--

CREATE TABLE public.match_results (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    price_item_id uuid,
    confidence_score double precision NOT NULL,
    source text NOT NULL,
    decision text NOT NULL,
    reason text NOT NULL,
    created_by text NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_confidence_range CHECK (((confidence_score >= (0)::double precision) AND (confidence_score <= (100)::double precision))),
    CONSTRAINT check_decision_valid CHECK ((decision = ANY (ARRAY['auto-accepted'::text, 'manual-review'::text, 'rejected'::text]))),
    CONSTRAINT check_source_valid CHECK ((source = ANY (ARRAY['mapping_memory'::text, 'fuzzy_match'::text, 'review_ui'::text])))
);


ALTER TABLE public.match_results OWNER TO bimcalc;

--
-- Name: price_items; Type: TABLE; Schema: public; Owner: bimcalc
--

CREATE TABLE public.price_items (
    id uuid NOT NULL,
    classification_code integer NOT NULL,
    vendor_id text,
    sku text NOT NULL,
    description text NOT NULL,
    unit text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    currency character varying(3) NOT NULL,
    vat_rate numeric(5,2),
    width_mm double precision,
    height_mm double precision,
    dn_mm double precision,
    angle_deg double precision,
    material text,
    last_updated timestamp with time zone,
    vendor_note text,
    attributes json NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    item_code text NOT NULL,
    region text NOT NULL,
    source_name text NOT NULL,
    source_currency character varying(3) NOT NULL,
    original_effective_date timestamp with time zone,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    is_current boolean NOT NULL,
    org_id text NOT NULL,
    CONSTRAINT check_unit_price_non_negative CHECK ((unit_price >= (0)::numeric)),
    CONSTRAINT check_valid_period CHECK (((valid_to IS NULL) OR (valid_to > valid_from)))
);


ALTER TABLE public.price_items OWNER TO bimcalc;

--
-- Data for Name: data_sync_log; Type: TABLE DATA; Schema: public; Owner: bimcalc
--

COPY public.data_sync_log (id, run_timestamp, source_name, status, records_updated, records_inserted, records_failed, message, error_details, duration_seconds, created_at) FROM stdin;
b5a3349b-90b7-4114-b357-7fbc994fd7b7	2025-11-13 23:20:54.686734+00	test_prices_local	SUCCESS	0	10	0	Processed 10 records: 10 new, 0 updated, 0 unchanged, 0 failed	null	0	2025-11-13 23:20:54.719578+00
78ebbced-825e-4e65-834f-54e45cd553f6	2025-11-13 23:44:57.477939+00	test_prices_local	SUCCESS	0	0	0	Processed 10 records: 0 new, 0 updated, 10 unchanged, 0 failed	null	0	2025-11-13 23:44:57.508887+00
56f4a3b9-045d-48f0-9f5d-982df94db5d8	2025-11-14 01:12:12.585596+00	test_prices_local	SUCCESS	0	0	0	Processed 10 records: 0 new, 0 updated, 10 unchanged, 0 failed	null	0	2025-11-14 01:12:12.631478+00
c2ea206e-fa5c-4988-8981-aa2234b6a284	2025-11-14 08:01:52.856329+00	demo_api_multi_region	SUCCESS	0	30	0	Processed 30 records: 30 new, 0 updated, 0 unchanged, 0 failed	null	0	2025-11-14 08:01:53.577312+00
db0f9fca-0cb8-498c-9c71-dd9c673609e5	2025-11-14 08:01:52.856329+00	test_prices_local	SUCCESS	0	0	0	Processed 10 records: 0 new, 0 updated, 10 unchanged, 0 failed	null	0	2025-11-14 08:01:53.59353+00
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: bimcalc
--

COPY public.documents (id, title, content, doc_metadata, doc_type, source_file, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: item_mapping; Type: TABLE DATA; Schema: public; Owner: bimcalc
--

COPY public.item_mapping (id, org_id, canonical_key, price_item_id, start_ts, end_ts, created_by, reason) FROM stdin;
c3a6a820-3793-4ede-95cd-a984b4c42bc5	default	1b421cd09884de74	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	2025-11-08 17:32:09.798023+00	\N	web-ui	auto-accept
cf0a5584-5802-4dca-aa46-e75699fabf6f	default	42df9309230b7a7a	13fbd16a-21ad-4117-9911-fafdb9d51174	2025-11-08 17:32:09.805293+00	\N	web-ui	auto-accept
96855bfc-638c-4920-84e4-20a490d3dbd0	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:13.814651+00	2025-11-08 21:28:16.237562+00	web-ui	review-ui approval
b9889b04-6da8-4f91-8a82-023099786eab	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:16.237562+00	2025-11-08 21:28:17.442959+00	web-ui	review-ui approval
28d9aea5-0000-4843-b981-191f7a1577ab	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:17.442959+00	2025-11-08 21:28:18.131822+00	web-ui	review-ui approval
6c46f3cb-4aa3-41ab-98eb-55c36395093c	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:18.131822+00	2025-11-08 21:28:21.508241+00	web-ui	review-ui approval
361ff3db-1a7d-477d-8674-c42d873c15bb	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:21.508241+00	2025-11-08 21:28:40.632844+00	web-ui	review-ui approval
529ac99d-930f-4ed5-8256-63e484be7d67	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:40.632844+00	2025-11-08 21:28:42.254449+00	web-ui	review-ui approval
4ea08637-3d8e-4997-8669-f65a1f150027	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:42.254449+00	2025-11-08 21:28:44.853275+00	web-ui	review-ui approval
7f90e436-c684-4add-8fdf-97ce65cd6bd1	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:44.853275+00	2025-11-08 21:28:45.55176+00	web-ui	review-ui approval
64febf32-a783-429c-952b-923fd2076160	default	36665b8fef6e716e	da1c9a43-903d-40e8-895d-f376cc2fba6c	2025-11-08 21:28:31.730378+00	2025-11-08 21:28:49.096079+00	web-ui	review-ui approval
d9fd8d1d-6932-43df-9f8b-99136e2ea87b	default	36665b8fef6e716e	da1c9a43-903d-40e8-895d-f376cc2fba6c	2025-11-08 21:28:49.096079+00	\N	web-ui	review-ui approval
4eadc5f2-7099-4405-a194-ef15aaae5d75	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:28:45.55176+00	2025-11-08 21:29:02.668016+00	web-ui	review-ui approval
4fdd0a64-7b69-403f-ba6a-9fa55f3f67a8	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-08 21:29:02.668016+00	2025-11-10 17:55:09.307694+00	web-ui	review-ui approval
b4b61445-4d30-433f-89af-4509fb77ba38	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-10 17:55:09.307694+00	2025-11-10 17:55:16.319544+00	web-ui	kjhiu
43c3062e-eba1-4a55-acf5-5a76e7897ccd	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-10 17:55:16.319544+00	2025-11-13 08:47:18.477924+00	web-ui	,mnbljn
4a729261-a5a4-47ef-8bf7-20639f2d0b19	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:47:18.477924+00	2025-11-13 08:47:26.326249+00	web-ui	Looks like a good match based on description.
2c9a9ded-4f39-40d4-b22b-d4f06878b72a	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:47:26.326249+00	2025-11-13 08:47:33.304491+00	web-ui	Looks like a good match based on description.
19ddbc5a-7832-448d-801d-3a1f3a7c3603	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:47:33.304491+00	2025-11-13 08:47:39.945828+00	web-ui	Looks like a good match based on description.
2728641a-0a87-41f8-a1e2-0ac6fd9b96cd	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:47:39.945828+00	2025-11-13 08:47:46.612947+00	web-ui	Looks like a good match based on description.
83e575c9-0fcc-41c9-8b85-07188c6a2aa2	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:47:46.612947+00	2025-11-13 08:47:54.632538+00	web-ui	Looks like a good match based on description.
88f2e81c-503b-4d40-b341-be2c1504d86f	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:47:54.632538+00	2025-11-13 08:48:02.633339+00	web-ui	Looks like a good match based on description.
1f5d3390-bde7-473c-940c-5098a27a34fb	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:48:02.633339+00	2025-11-13 08:48:10.687562+00	web-ui	Looks like a good match based on description.
11e4d905-0480-4a2f-b303-28520f3e23a3	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:48:10.687562+00	2025-11-13 08:48:28.204372+00	web-ui	Looks like a good match based on description.
148a7815-3252-4327-9d0b-217b1664c955	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:48:28.204372+00	2025-11-13 08:48:45.766252+00	web-ui	Looks like a good match based on description.
7621a96d-5279-4992-9793-055debd9f4ff	default	79ec61771668c7b0	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	2025-11-08 21:28:32.838523+00	2025-11-13 08:48:54.366378+00	web-ui	review-ui approval
63f88a75-a746-4328-937e-18307b464418	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:48:45.766252+00	2025-11-13 08:50:18.972617+00	web-ui	review-ui approval
7f42d304-883c-47f7-b7ee-d9b3c6351a06	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:50:18.972617+00	2025-11-13 08:50:45.492759+00	web-ui	Match looks good, vendor note acknowledged.
9cdb6be1-8c48-4688-9313-c63cee3b649f	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 08:50:45.492759+00	2025-11-13 18:48:59.552845+00	web-ui	Match looks good, vendor note acknowledged.
740c7bdc-5f89-4e76-b4c8-9843078bf156	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 18:48:59.552845+00	2025-11-13 22:50:25.550234+00	web-ui	hi
eeeaf4fd-1cf3-474c-991d-6f7d533fa489	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 22:50:25.550234+00	2025-11-13 23:22:48.148944+00	web-ui	;km;kn;
81de865b-1dd0-4cb4-a8b3-4eb3cf61178b	default	16b06c6ae828980c	2321d513-8ed6-4ecf-8966-9145e9714e1f	2025-11-13 23:22:48.148944+00	\N	web-ui	kjhiu
c4957997-6f83-4f33-9744-8e0bf7e145b1	default	79ec61771668c7b0	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	2025-11-13 08:48:54.366378+00	2025-11-14 22:00:09.157173+00	web-ui	review-ui approval
a3673bbb-1e26-46b8-8465-a499a507270b	default	79ec61771668c7b0	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	2025-11-14 22:00:09.157173+00	2025-11-14 22:00:12.401289+00	web-ui	review-ui approval
e7bd534a-dde9-43a6-a7d6-be4e021a5ca3	default	79ec61771668c7b0	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	2025-11-14 22:00:12.401289+00	\N	web-ui	,mnbljn
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: bimcalc
--

COPY public.items (id, org_id, project_id, classification_code, canonical_key, category, family, type_name, system_type, omniclass_code, uniformat_code, quantity, unit, width_mm, height_mm, dn_mm, angle_deg, material, source_file, created_at) FROM stdin;
511b5903-a323-4485-a7fc-865f5ebd466d	default	default	2650	16b06c6ae828980c	Cable Tray	Cable Tray - Ladder	Elbow 90deg 200x50mm Galvanized	\N	\N	\N	12.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
564ff7c9-9ffd-4188-b791-ac3cccbdf37b	default	default	2650	8831d010fff4d65a	Cable Tray	Cable Tray - Ladder	Straight 200x50mm Galvanized 3000mm	\N	\N	\N	45.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
0166a311-ebc0-4bde-8ec9-d6c11e0b4362	default	default	2650	1b421cd09884de74	Cable Tray	Cable Tray - Ladder	Elbow 45deg 300x50mm Galvanized	\N	\N	\N	8.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	default	default	2650	79ec61771668c7b0	Cable Tray	Cable Tray - Ladder	Tee 200x50mm Galvanized	\N	\N	\N	6.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
7c1e6a87-9bf7-4207-829d-5d8e2a65c8b2	default	default	2650	42df9309230b7a7a	Cable Tray	Cable Tray - Ladder	Reducer 300x50 to 200x50 Galvanized	\N	\N	\N	4.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
312f941f-59d0-4ceb-b6c2-4c004e47c6b0	default	default	2215	9b138a902d2e9ff2	Pipes	Pipe - MEP Fabrication	90 Elbow DN50 Galvanized	\N	\N	\N	24.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
d78382fe-7b65-4628-8639-9dd790efe7be	default	default	9999	d4504c0bbfeb62b1	Pipes	Pipe - MEP Fabrication	Straight DN50 Galvanized 6000mm	\N	\N	\N	120.00	m	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
b2e1e9d1-c1f5-4a4f-827b-86127eef832f	default	default	2215	5c8fc664c7ebe9e2	Pipes	Pipe - MEP Fabrication	90 Elbow DN100 Galvanized	\N	\N	\N	18.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
35c7ab47-1103-4e1d-b416-d0be382e3aee	default	default	2215	dfc29aabb465d3fb	Pipes	Pipe - MEP Fabrication	Tee DN50 Galvanized	\N	\N	\N	15.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
b17a7bb9-d15a-46d8-a9da-f83a2d98b93b	default	default	2215	07bf2f056061337f	Pipes	Pipe - MEP Fabrication	45 Elbow DN50 Galvanized	\N	\N	\N	10.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
e017e453-504d-40c5-a10c-452b8076fc97	default	default	2650	44fc1979675d5caf	Conduit	Conduit - Rigid	90 Elbow 25mm PVC	\N	\N	\N	30.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
3cac436a-2d8f-4ad0-bb48-6e91484ba877	default	default	2650	556927391780c781	Conduit	Conduit - Rigid	Straight 25mm PVC 3000mm	\N	\N	\N	85.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
d27082cd-7dbf-4e86-b215-10b15358f0f6	default	default	2650	4944171ab5511ee0	Conduit	Conduit - Rigid	Coupling 25mm PVC	\N	\N	\N	40.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
23844685-c033-4532-ab11-fa2aa8fa9945	default	default	2302	57f48c73992c3c17	Ducts	Duct - Rectangular	Elbow 90deg 300x200mm Galvanized	\N	\N	\N	10.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
04a2c06f-40ac-4de2-a442-832ea8b90502	default	default	2302	5ce886dd8453502e	Ducts	Duct - Rectangular	Straight 300x200mm Galvanized 1200mm	\N	\N	\N	32.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
d7987189-bbc8-44e3-b152-f293552d679a	default	default	2650	36665b8fef6e716e	Cable Tray	Cable Tray - Perforated	Elbow 90deg 150x50mm Stainless	\N	\N	\N	6.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
7be0d480-6f33-4162-9ddf-cfd4a1bc6338	default	default	2215	b9907a40de01eda8	Pipes	Pipe - Copper	90 Elbow DN32 Copper Type K	\N	\N	\N	20.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
6f1dbed6-1978-4b0e-895a-8c90fc961288	default	default	9999	905b0dcbaf74d8ba	Pipes	Pipe - Copper	Straight DN32 Copper Type K	\N	\N	\N	80.00	m	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
6573c446-39f8-4732-ba98-8553843728ad	default	default	2603	bdf8310dd97757a2	Lighting	Lighting Fixture	LED Panel 600x600 40W	\N	\N	\N	120.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
6a2c9293-e82d-4ace-86f8-7150b05a9715	default	default	2603	46aaad99cf0d9029	Lighting	Lighting Fixture	LED Downlight 150mm 12W	\N	\N	\N	85.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:21:30.794769+00
070279bb-4a76-4c9c-8577-64a7758937c4	default	default	2650	16b06c6ae828980c	Cable Tray	Cable Tray - Ladder	Elbow 90deg 200x50mm Galvanized	\N	\N	\N	12.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
7f721c79-9d6f-426d-ad1e-d98af036f00e	default	default	2650	8831d010fff4d65a	Cable Tray	Cable Tray - Ladder	Straight 200x50mm Galvanized 3000mm	\N	\N	\N	45.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
0ec08269-9419-4ae3-9d7f-595d3a090213	default	default	2650	1b421cd09884de74	Cable Tray	Cable Tray - Ladder	Elbow 45deg 300x50mm Galvanized	\N	\N	\N	8.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
cb3c7b0f-465b-4d1c-9ef7-ca5b45aa987f	default	default	2650	79ec61771668c7b0	Cable Tray	Cable Tray - Ladder	Tee 200x50mm Galvanized	\N	\N	\N	6.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
3c5e1ef3-323a-456e-a5b8-398df800f414	default	default	2650	42df9309230b7a7a	Cable Tray	Cable Tray - Ladder	Reducer 300x50 to 200x50 Galvanized	\N	\N	\N	4.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
feddacad-7bfd-4407-a7f4-d92d8d67de95	default	default	2215	9b138a902d2e9ff2	Pipes	Pipe - MEP Fabrication	90 Elbow DN50 Galvanized	\N	\N	\N	24.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
5f02fa33-36c9-4445-bdd1-367e80e8277b	default	default	9999	d4504c0bbfeb62b1	Pipes	Pipe - MEP Fabrication	Straight DN50 Galvanized 6000mm	\N	\N	\N	120.00	m	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
f04b7ec2-8b5a-42fc-87df-9ac455de5943	default	default	2215	5c8fc664c7ebe9e2	Pipes	Pipe - MEP Fabrication	90 Elbow DN100 Galvanized	\N	\N	\N	18.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
1407d6ad-f8df-4512-af46-86b7b2579f33	default	default	2215	dfc29aabb465d3fb	Pipes	Pipe - MEP Fabrication	Tee DN50 Galvanized	\N	\N	\N	15.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
7248e810-72e5-45ca-a756-6dfa08e64692	default	default	2215	07bf2f056061337f	Pipes	Pipe - MEP Fabrication	45 Elbow DN50 Galvanized	\N	\N	\N	10.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
7d30bc21-5d47-4bbf-9b23-406ee50345d0	default	default	2650	44fc1979675d5caf	Conduit	Conduit - Rigid	90 Elbow 25mm PVC	\N	\N	\N	30.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
edb0a01b-6d84-444a-bc49-bfd9cc2094b4	default	default	2650	556927391780c781	Conduit	Conduit - Rigid	Straight 25mm PVC 3000mm	\N	\N	\N	85.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
1d2e4506-2aa4-4c1b-a02c-082a058cae7d	default	default	2650	4944171ab5511ee0	Conduit	Conduit - Rigid	Coupling 25mm PVC	\N	\N	\N	40.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
517f045b-fd64-4a80-9bce-462c4b1cf069	default	default	2302	57f48c73992c3c17	Ducts	Duct - Rectangular	Elbow 90deg 300x200mm Galvanized	\N	\N	\N	10.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
fedb546b-35b3-422c-ad21-a6978ee7a55b	default	default	2302	5ce886dd8453502e	Ducts	Duct - Rectangular	Straight 300x200mm Galvanized 1200mm	\N	\N	\N	32.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
1335170f-9dfd-4ac5-be84-67d83640a1df	default	default	2650	36665b8fef6e716e	Cable Tray	Cable Tray - Perforated	Elbow 90deg 150x50mm Stainless	\N	\N	\N	6.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
a2bde469-62b9-4f10-9d5f-050ad47f0420	default	default	2215	b9907a40de01eda8	Pipes	Pipe - Copper	90 Elbow DN32 Copper Type K	\N	\N	\N	20.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
6839a697-1e0f-4e9f-817b-f6b5cd9dbb36	default	default	9999	905b0dcbaf74d8ba	Pipes	Pipe - Copper	Straight DN32 Copper Type K	\N	\N	\N	80.00	m	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
ab4bec92-c0e9-4b5a-8b73-b5ee8f7f5e35	default	default	2603	bdf8310dd97757a2	Lighting	Lighting Fixture	LED Panel 600x600 40W	\N	\N	\N	120.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
ac03e065-3b83-44f3-a4cc-6b23dd3d0364	default	default	2603	46aaad99cf0d9029	Lighting	Lighting Fixture	LED Downlight 150mm 12W	\N	\N	\N	85.00	ea	\N	\N	\N	\N	\N	/tmp/revit_schedule_demo.csv	2025-11-08 17:31:55.051546+00
\.


--
-- Data for Name: match_flags; Type: TABLE DATA; Schema: public; Owner: bimcalc
--

COPY public.match_flags (id, match_result_id, item_id, price_item_id, flag_type, severity, message, created_at) FROM stdin;
c915e633-bf36-41dd-a88c-769b4dcea214	74dc53a0-58b7-4586-98dc-6b16b0ad4486	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 18:39:40.438215+00
0b18be9e-be01-4c87-b6e5-70c307d05e32	2d0828f3-7e1d-4ffb-897b-b3d29dcb1c6b	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	VendorNote	Advisory	Vendor note: Per 3m length	2025-11-08 18:39:40.438215+00
47b0588c-bb26-49fc-942d-4da076d27d71	0d58013a-53ed-4dba-9079-e83058403156	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 18:40:38.210825+00
9274340a-50c4-4233-be1d-b5919775642c	12aa4bf3-5b5b-4e9c-807a-80ca11d420c4	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	VendorNote	Advisory	Vendor note: Per 3m length	2025-11-08 18:40:38.210825+00
c0fa5fcb-f6c1-4996-8120-18b84bafd89f	76ed9cc9-53a4-4f84-9db5-5c8bf6df4667	d7987189-bbc8-44e3-b152-f293552d679a	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material	2025-11-08 18:40:38.210825+00
7dc9ecf1-c1cc-469f-bba2-759e6e7e9ce5	273527d3-39ec-4b88-b702-8304209334fb	070279bb-4a76-4c9c-8577-64a7758937c4	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 18:40:38.210825+00
1cdc1424-306a-45ec-8e1d-e1e43c0a5b22	72235333-7b29-4cd9-bc29-c136aec20562	7f721c79-9d6f-426d-ad1e-d98af036f00e	92aa4216-c788-4836-8e30-c2c7c988c3d3	VendorNote	Advisory	Vendor note: Per 3m length	2025-11-08 18:40:38.210825+00
efd71ca4-de78-4bd4-9c03-47e9d3275433	4e413815-31b4-4391-a032-a01fee8a7353	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material	2025-11-08 18:40:38.210825+00
d828e7db-7ddc-40b4-9724-c063f6602683	be08e117-19d7-4013-b843-fe97cc5457ef	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:13.811165+00
bb6226c5-bee1-4200-8016-b947930c61ab	30ae9dca-4848-4df4-b3a4-018372b7426e	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:16.234738+00
76954456-2bb5-4989-8393-e2fdcac3299b	fbc3747d-89e4-439f-869d-b9c8b1dd60b7	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:17.440505+00
d4c611fa-2652-49ac-b64a-f925225087ec	2f9c25ef-91d0-475d-9493-e5575979ba6c	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:18.129235+00
2b09392b-8e6c-4241-8205-f0a4dfa6f1b1	7c1c2c43-3936-4fde-b4aa-b9ce68e79c75	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:21.506663+00
068c0378-7cab-4731-8868-a74686472003	169915bc-20d0-4031-b6c3-3c9fd7c6cf0f	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material	2025-11-08 21:28:31.728004+00
ae49f4a9-5f13-4a52-8bd0-add5bd3206c8	971f4be9-604b-44d5-8cb4-502a33ca3fb3	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:40.629491+00
d63a8825-d525-47ee-bee3-a3a3b8eca5cc	cc8e179d-24eb-4830-a92a-5d7ce27d852b	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:42.252034+00
040db4e6-9b40-4b73-9587-fd04bbc8877c	58ecf9fe-6ef8-4c42-bad7-08199a671a7a	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:44.850451+00
6b9d1d9a-a984-4185-ab74-e5ec07fafbf3	13110f08-7f0d-4cb2-a1f9-10154bd45a0c	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:28:45.549554+00
70c10c3f-e43c-4905-821a-9b9377b935fd	9e77371c-4c89-48ee-8c0d-de18f494bc2a	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material	2025-11-08 21:28:49.093613+00
54f6e118-365c-47cf-a2e7-70d92d830c7d	da4f7611-5891-4269-9725-515df6622c86	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-08 21:29:02.666276+00
db292af2-2ee2-4358-b7e9-f23bb1fb119f	4c2c5d5a-f38c-4bd8-8b5b-24753f4d1d13	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-10 17:55:09.303872+00
f05852f5-c2c8-4a64-b05a-9740448f020c	71ad8336-d02f-4f6c-b63e-7bbdf3df2d97	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-10 17:55:16.316842+00
b6eae81c-70ea-4243-8604-06b8d61564f5	3c661200-70f5-479b-b60d-b9c27f1554f0	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:47:18.475146+00
ecea57d3-86e8-49d9-b478-33133e40fb3e	1603c72f-5e09-4041-8ec7-8db0204deacb	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:47:26.324373+00
d158d30a-e077-4039-b299-4bdb1eb11a31	005f087e-0cef-43f0-a899-43cafa62ffdb	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:47:33.301035+00
28e85273-6f0c-4b99-8cb8-90b5c4f26d2d	44840add-f8f9-4106-96cb-0f3ab25e8532	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:47:39.942468+00
c358af88-43e1-4107-b889-9490b757bb6f	e982d2af-653d-49f0-9733-8ec47f07c54f	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:47:46.609082+00
52bc17c2-3cde-4f60-8b2b-19577eaf34c2	1526c27a-de8b-47bd-bfc9-bdadb903a2d7	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:47:54.6287+00
7b1e03f3-9a36-4878-a00c-ac2353c4f516	a24c3b99-faae-41f6-bcc9-223f8777598a	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:48:02.630036+00
4bbb8c44-1132-4b2f-93e0-000bd38d7725	c5dfc1cf-b0c9-4ebf-b76c-aacf21b6bca8	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:48:10.686334+00
a01d10b6-bb95-4842-9db2-fe67678d621f	f232549e-5ebc-457b-ad87-b00204da85d3	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:48:28.201405+00
4beec6ff-1f1e-4398-80f8-c101b0fcdbd0	edc49c0c-54dd-4eb1-9a24-88c9c41643dc	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:48:45.763479+00
e07ddcb2-64ff-47c5-ae31-a99be454f9f5	4e653049-b9f3-420c-acf2-f9d7726f7b4c	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:50:18.971232+00
b3fdc612-eca7-4d6b-bcc6-d6e12dfb3570	db41f6ba-9e67-4657-9f51-1581a4cfd73d	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 08:50:45.490421+00
45d102fe-c64d-401c-ac20-69ea55455cf2	2695ff6d-5e98-441c-9aa0-716a4f336816	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 18:48:59.549285+00
5d38dc6e-2d1d-4ee3-b62c-e9479584132e	2a32b729-078e-4ac4-89d2-b1ec0020ff25	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 22:50:25.548315+00
1e83ddea-77fe-498c-98bd-4de4613721ba	6c665c24-5324-4e25-8221-b61fdc992716	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 23:22:48.145622+00
afd13e56-613c-45e7-af45-ba987cbab72f	36d897a9-9d11-4002-b531-d9da3109b438	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 23:23:40.712515+00
5ffa8d73-fbef-40b2-956c-8982c1d852fe	39b63e54-ebfc-4c3f-b705-3008dbe797ed	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	VendorNote	Advisory	Vendor note: Per 3m length	2025-11-13 23:23:40.712515+00
ea7c346f-fbb5-4339-ae8e-c1d942e1e900	58690b0a-104e-4c6b-a52b-19729f04bad3	d7987189-bbc8-44e3-b152-f293552d679a	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material	2025-11-13 23:23:40.712515+00
a1e9e448-35d3-44b2-b3f4-12ef77153cdb	88dc416f-9891-4259-b33e-4ec6557cff52	070279bb-4a76-4c9c-8577-64a7758937c4	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item	2025-11-13 23:23:40.712515+00
58826ad8-ed1b-4520-b8b9-95d98075769d	4f193a9d-f224-403a-9f89-536a325312c2	7f721c79-9d6f-426d-ad1e-d98af036f00e	92aa4216-c788-4836-8e30-c2c7c988c3d3	VendorNote	Advisory	Vendor note: Per 3m length	2025-11-13 23:23:40.712515+00
62874ac8-6789-47cb-9d6b-6d23dfef1a84	3d4decd8-29de-4f4b-8deb-f39d2a1f5d50	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material	2025-11-13 23:23:40.712515+00
0e7e8643-9031-4eb6-8887-42c80a61164e	d388ab0f-f477-4933-8a0f-cdab49c32609	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item [org:default project:default Cable Tray - Ladder:Elbow 90deg 200x50mm Galvanized]	2025-11-14 22:03:32.433742+00
b88fe7d9-da01-43f5-86c3-404141bfda80	77de67de-71ae-47dc-90cb-c94d5a5527a6	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	VendorNote	Advisory	Vendor note: Per 3m length [org:default project:default Cable Tray - Ladder:Straight 200x50mm Galvanized 3000mm]	2025-11-14 22:03:32.433742+00
7d431cf1-9601-4da2-8916-e4e6a7673152	a8d43f6a-7a99-4a7d-82db-f1d63add2a7c	d78382fe-7b65-4628-8639-9dd790efe7be	0f177c58-7717-4dc9-87ac-1db888db1e13	Class Mismatch	Critical-Veto	Item class 9999 differs from price class 2211 [org:default project:default Pipe - MEP Fabrication:Straight DN50 Galvanized 6000mm]	2025-11-14 22:03:32.433742+00
22c85744-ef76-45b2-a19b-755f34d7c0c5	a8d43f6a-7a99-4a7d-82db-f1d63add2a7c	d78382fe-7b65-4628-8639-9dd790efe7be	0f177c58-7717-4dc9-87ac-1db888db1e13	VendorNote	Advisory	Vendor note: Per meter [org:default project:default Pipe - MEP Fabrication:Straight DN50 Galvanized 6000mm]	2025-11-14 22:03:32.433742+00
a8db2ec8-2ca5-4fde-a30f-06fd924d3b5c	a8d43f6a-7a99-4a7d-82db-f1d63add2a7c	d78382fe-7b65-4628-8639-9dd790efe7be	0f177c58-7717-4dc9-87ac-1db888db1e13	Classification Mismatch	Critical-Veto	Out-of-class match via escape-hatch: item class=9999, price class=2211	2025-11-14 22:03:32.433742+00
9b4a0b95-5a48-410b-9da9-fb4906befe68	18069180-bf7c-44f2-a962-8c3101acae7b	d7987189-bbc8-44e3-b152-f293552d679a	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material [org:default project:default Cable Tray - Perforated:Elbow 90deg 150x50mm Stainless]	2025-11-14 22:03:32.433742+00
ad29e765-3ebc-49d7-86d2-ad7230a58b71	d3a854e9-b7c9-42c1-8741-abd7b0b7dece	6f1dbed6-1978-4b0e-895a-8c90fc961288	10aa1b09-881c-4119-945c-3b7abd6a9405	Class Mismatch	Critical-Veto	Item class 9999 differs from price class 2211 [org:default project:default Pipe - Copper:Straight DN32 Copper Type K]	2025-11-14 22:03:32.433742+00
3114d933-3820-4d76-80a8-41bdc1456fa2	d3a854e9-b7c9-42c1-8741-abd7b0b7dece	6f1dbed6-1978-4b0e-895a-8c90fc961288	10aa1b09-881c-4119-945c-3b7abd6a9405	VendorNote	Advisory	Vendor note: Per meter [org:default project:default Pipe - Copper:Straight DN32 Copper Type K]	2025-11-14 22:03:32.433742+00
b96ca890-573d-4fb2-ada6-99d3e53904b5	d3a854e9-b7c9-42c1-8741-abd7b0b7dece	6f1dbed6-1978-4b0e-895a-8c90fc961288	10aa1b09-881c-4119-945c-3b7abd6a9405	Classification Mismatch	Critical-Veto	Out-of-class match via escape-hatch: item class=9999, price class=2211	2025-11-14 22:03:32.433742+00
e956b3a9-e1d7-4fa4-b129-3faec7c2a991	4b3ac93e-126d-4bd0-b692-3baae3a8d7e5	070279bb-4a76-4c9c-8577-64a7758937c4	2321d513-8ed6-4ecf-8966-9145e9714e1f	VendorNote	Advisory	Vendor note: Standard stock item [org:default project:default Cable Tray - Ladder:Elbow 90deg 200x50mm Galvanized]	2025-11-14 22:03:32.433742+00
97763cc1-8d35-4f12-86ce-60e33dbe5e9e	ca06fc8a-c0b5-43a2-afb5-0618bc51d33e	7f721c79-9d6f-426d-ad1e-d98af036f00e	92aa4216-c788-4836-8e30-c2c7c988c3d3	VendorNote	Advisory	Vendor note: Per 3m length [org:default project:default Cable Tray - Ladder:Straight 200x50mm Galvanized 3000mm]	2025-11-14 22:03:32.433742+00
a4634888-c847-4c66-9b2f-e32ec5615f01	197387a5-61cf-414e-ba36-8ac5a0def6bf	5f02fa33-36c9-4445-bdd1-367e80e8277b	0f177c58-7717-4dc9-87ac-1db888db1e13	Class Mismatch	Critical-Veto	Item class 9999 differs from price class 2211 [org:default project:default Pipe - MEP Fabrication:Straight DN50 Galvanized 6000mm]	2025-11-14 22:03:32.433742+00
73ccf9d0-2739-4d4b-9764-3d7213ec7585	197387a5-61cf-414e-ba36-8ac5a0def6bf	5f02fa33-36c9-4445-bdd1-367e80e8277b	0f177c58-7717-4dc9-87ac-1db888db1e13	VendorNote	Advisory	Vendor note: Per meter [org:default project:default Pipe - MEP Fabrication:Straight DN50 Galvanized 6000mm]	2025-11-14 22:03:32.433742+00
276df38d-a696-4ef0-becd-b1c1ec2cfc9b	197387a5-61cf-414e-ba36-8ac5a0def6bf	5f02fa33-36c9-4445-bdd1-367e80e8277b	0f177c58-7717-4dc9-87ac-1db888db1e13	Classification Mismatch	Critical-Veto	Out-of-class match via escape-hatch: item class=9999, price class=2211	2025-11-14 22:03:32.433742+00
ddac6938-715b-451f-9057-e06d8113dfdf	acef4b27-a011-4875-b45b-03c4df63fd7e	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	VendorNote	Advisory	Vendor note: Premium material [org:default project:default Cable Tray - Perforated:Elbow 90deg 150x50mm Stainless]	2025-11-14 22:03:32.433742+00
64f760bb-c368-4aec-b7c0-ba2812487e00	8c52ee6f-dad5-46ca-bd86-4fcedcbe4ed2	6839a697-1e0f-4e9f-817b-f6b5cd9dbb36	10aa1b09-881c-4119-945c-3b7abd6a9405	Class Mismatch	Critical-Veto	Item class 9999 differs from price class 2211 [org:default project:default Pipe - Copper:Straight DN32 Copper Type K]	2025-11-14 22:03:32.433742+00
9712f0bb-eaf5-41ec-bbb2-153cb0c0f4b6	8c52ee6f-dad5-46ca-bd86-4fcedcbe4ed2	6839a697-1e0f-4e9f-817b-f6b5cd9dbb36	10aa1b09-881c-4119-945c-3b7abd6a9405	VendorNote	Advisory	Vendor note: Per meter [org:default project:default Pipe - Copper:Straight DN32 Copper Type K]	2025-11-14 22:03:32.433742+00
11e2036f-5f6d-4ffe-a55b-c384f0ce05c5	8c52ee6f-dad5-46ca-bd86-4fcedcbe4ed2	6839a697-1e0f-4e9f-817b-f6b5cd9dbb36	10aa1b09-881c-4119-945c-3b7abd6a9405	Classification Mismatch	Critical-Veto	Out-of-class match via escape-hatch: item class=9999, price class=2211	2025-11-14 22:03:32.433742+00
\.


--
-- Data for Name: match_results; Type: TABLE DATA; Schema: public; Owner: bimcalc
--

COPY public.match_results (id, item_id, price_item_id, confidence_score, source, decision, reason, created_by, "timestamp") FROM stdin;
74dc53a0-58b7-4586-98dc-6b16b0ad4486	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	fuzzy_match	manual-review	Manual review required: flags: VendorNote	cli-test	2025-11-08 18:39:40.447295+00
2d0828f3-7e1d-4ffb-897b-b3d29dcb1c6b	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	80	fuzzy_match	manual-review	Manual review required: confidence 80.0% < 85%; flags: VendorNote	cli-test	2025-11-08 18:39:40.451481+00
cf57aaf2-e7ac-49f5-a83a-1bf1ab03ae95	0166a311-ebc0-4bde-8ec9-d6c11e0b4362	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli-test	2025-11-08 18:39:40.453803+00
888b1e81-f10a-47a6-ade6-a74fbe3bc045	14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	83.87096774193549	fuzzy_match	manual-review	Manual review required: confidence 83.9% < 85%	cli-test	2025-11-08 18:39:40.455864+00
df6b9674-7e35-4ffe-b9aa-409ad3bd2283	7c1e6a87-9bf7-4207-829d-5d8e2a65c8b2	13fbd16a-21ad-4117-9911-fafdb9d51174	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli-test	2025-11-08 18:39:40.457807+00
0d58013a-53ed-4dba-9079-e83058403156	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	fuzzy_match	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-08 18:40:38.220754+00
12aa4bf3-5b5b-4e9c-807a-80ca11d420c4	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	80	fuzzy_match	manual-review	Manual review required: confidence 80.0% < 85%; flags: VendorNote	web-ui	2025-11-08 18:40:38.225134+00
4cea94ca-5fb2-4952-8ab5-a844512ce2dd	0166a311-ebc0-4bde-8ec9-d6c11e0b4362	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-08 18:40:38.227587+00
67e93d10-f18a-4a3b-a6b7-59b9636bbdff	14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	83.87096774193549	fuzzy_match	manual-review	Manual review required: confidence 83.9% < 85%	web-ui	2025-11-08 18:40:38.229049+00
44598218-0ef3-482f-8ee4-42f6fd457a9b	7c1e6a87-9bf7-4207-829d-5d8e2a65c8b2	13fbd16a-21ad-4117-9911-fafdb9d51174	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-08 18:40:38.230345+00
35f360db-7d90-4d34-8006-0bb4a2b7b931	312f941f-59d0-4ceb-b6c2-4c004e47c6b0	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.231402+00
b2e234f6-01f8-49b8-bb8e-c1c1dd585e52	d78382fe-7b65-4628-8639-9dd790efe7be	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.232565+00
0678ec15-df19-4a96-b77e-0575197401e0	b2e1e9d1-c1f5-4a4f-827b-86127eef832f	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.233632+00
a9cc199f-e3b0-4cf7-ab74-4a3739b1054f	35c7ab47-1103-4e1d-b416-d0be382e3aee	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.234748+00
25d7c158-b00a-4cdd-ba8d-0d81a157d1ef	b17a7bb9-d15a-46d8-a9da-f83a2d98b93b	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.236046+00
194fb0ef-4618-4fb0-8363-766d8a0de551	e017e453-504d-40c5-a10c-452b8076fc97	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-08 18:40:38.237717+00
6d510b9c-ab07-472e-a395-77bd294b9d86	3cac436a-2d8f-4ad0-bb48-6e91484ba877	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-08 18:40:38.238913+00
41ece23c-34fc-4c50-b64b-262767c40073	d27082cd-7dbf-4e86-b215-10b15358f0f6	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-08 18:40:38.240098+00
7f6a9a18-1a1c-4f91-92c4-d1ea4af5ad6a	23844685-c033-4532-ab11-fa2aa8fa9945	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.24106+00
201aa8d5-5a56-4c39-9aab-812d9dc7f898	04a2c06f-40ac-4de2-a442-832ea8b90502	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.242015+00
76ed9cc9-53a4-4f84-9db5-5c8bf6df4667	d7987189-bbc8-44e3-b152-f293552d679a	da1c9a43-903d-40e8-895d-f376cc2fba6c	93.45794392523365	fuzzy_match	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-08 18:40:38.243182+00
cf743276-f5f0-4513-a6f9-352e294a5f4a	7be0d480-6f33-4162-9ddf-cfd4a1bc6338	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.244793+00
ac18e249-304b-4470-b674-58f26d0c2ca4	6f1dbed6-1978-4b0e-895a-8c90fc961288	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.245953+00
c5c1e49b-6a6d-4600-b052-d451688f8f02	6573c446-39f8-4732-ba98-8553843728ad	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.247052+00
39018e4a-259a-4a7d-92a5-3804059937a8	6a2c9293-e82d-4ace-86f8-7150b05a9715	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.248206+00
273527d3-39ec-4b88-b702-8304209334fb	070279bb-4a76-4c9c-8577-64a7758937c4	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	fuzzy_match	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-08 18:40:38.249497+00
72235333-7b29-4cd9-bc29-c136aec20562	7f721c79-9d6f-426d-ad1e-d98af036f00e	92aa4216-c788-4836-8e30-c2c7c988c3d3	80	fuzzy_match	manual-review	Manual review required: confidence 80.0% < 85%; flags: VendorNote	web-ui	2025-11-08 18:40:38.251025+00
56844fc7-65b9-4739-96cc-0b0fc38f86fc	0ec08269-9419-4ae3-9d7f-595d3a090213	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-08 18:40:38.25245+00
38ba65f7-d5e7-44ae-8634-4e622364e056	cb3c7b0f-465b-4d1c-9ef7-ca5b45aa987f	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	83.87096774193549	fuzzy_match	manual-review	Manual review required: confidence 83.9% < 85%	web-ui	2025-11-08 18:40:38.25358+00
dc50e369-d663-4cb6-95bf-8cfa028bc4c9	3c5e1ef3-323a-456e-a5b8-398df800f414	13fbd16a-21ad-4117-9911-fafdb9d51174	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-08 18:40:38.254577+00
74830d29-e96d-4a51-bb8d-a269ddfe9985	feddacad-7bfd-4407-a7f4-d92d8d67de95	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.255494+00
419d5b39-dec0-4479-8d71-a04ddf79fa1b	5f02fa33-36c9-4445-bdd1-367e80e8277b	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.256567+00
e616c33f-63e7-415b-985f-8d2de93b5d40	f04b7ec2-8b5a-42fc-87df-9ac455de5943	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.257702+00
c7bcadca-7e90-4a78-8bd1-8861d5eeb7f8	1407d6ad-f8df-4512-af46-86b7b2579f33	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.2587+00
333c02ee-ba30-405b-ae10-81b2ef63584f	7248e810-72e5-45ca-a756-6dfa08e64692	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.259623+00
e6f8b267-6e12-4a6a-96ef-0a5f085eb1c1	7d30bc21-5d47-4bbf-9b23-406ee50345d0	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-08 18:40:38.260848+00
9f971a8f-561e-4ebf-92da-c480c66b638a	edb0a01b-6d84-444a-bc49-bfd9cc2094b4	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-08 18:40:38.261988+00
e1153373-70b4-44fe-a63e-c05175ab9190	1d2e4506-2aa4-4c1b-a02c-082a058cae7d	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-08 18:40:38.263078+00
03db82b6-4892-4e91-ab08-20379a41ff51	517f045b-fd64-4a80-9bce-462c4b1cf069	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.264036+00
4f52a06c-cb6b-43e7-8251-60dcb68b4f26	fedb546b-35b3-422c-ad21-a6978ee7a55b	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.26513+00
4e413815-31b4-4391-a032-a01fee8a7353	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	93.45794392523365	fuzzy_match	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-08 18:40:38.266365+00
cc9c91ed-34af-4f99-a3fc-64427a4c2b94	a2bde469-62b9-4f10-9d5f-050ad47f0420	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.267777+00
d1890b61-c616-4d8a-9e69-b6f9a5bae87b	6839a697-1e0f-4e9f-817b-f6b5cd9dbb36	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.268848+00
5b72d315-dddc-44ac-977a-e03e4535040b	ab4bec92-c0e9-4b5a-8b73-b5ee8f7f5e35	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.2699+00
d2ca0e7b-12c7-4745-94c6-6af06c178a07	ac03e065-3b83-44f3-a4cc-6b23dd3d0364	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-08 18:40:38.270943+00
be08e117-19d7-4013-b843-fe97cc5457ef	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:13.819931+00
30ae9dca-4848-4df4-b3a4-018372b7426e	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:16.239875+00
fbc3747d-89e4-439f-869d-b9c8b1dd60b7	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:17.445156+00
2f9c25ef-91d0-475d-9493-e5575979ba6c	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:18.13425+00
7c1c2c43-3936-4fde-b4aa-b9ce68e79c75	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:21.509747+00
169915bc-20d0-4031-b6c3-3c9fd7c6cf0f	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	93.45794392523365	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:31.732791+00
8b6e19ac-2eae-475b-b733-fe31d1427b09	cb3c7b0f-465b-4d1c-9ef7-ca5b45aa987f	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	83.87096774193549	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:32.840401+00
971f4be9-604b-44d5-8cb4-502a33ca3fb3	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:40.634493+00
cc8e179d-24eb-4830-a92a-5d7ce27d852b	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:42.256603+00
58ecf9fe-6ef8-4c42-bad7-08199a671a7a	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:44.855548+00
13110f08-7f0d-4cb2-a1f9-10154bd45a0c	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:45.553944+00
9e77371c-4c89-48ee-8c0d-de18f494bc2a	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	93.45794392523365	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:28:49.098375+00
da4f7611-5891-4269-9725-515df6622c86	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-08 21:29:02.669945+00
4c2c5d5a-f38c-4bd8-8b5b-24753f4d1d13	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: kjhiu	web-ui	2025-11-10 17:55:09.314591+00
71ad8336-d02f-4f6c-b63e-7bbdf3df2d97	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: ,mnbljn	web-ui	2025-11-10 17:55:16.321704+00
3c661200-70f5-479b-b60d-b9c27f1554f0	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:47:18.482229+00
1603c72f-5e09-4041-8ec7-8db0204deacb	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:47:26.330451+00
005f087e-0cef-43f0-a899-43cafa62ffdb	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:47:33.307206+00
44840add-f8f9-4106-96cb-0f3ab25e8532	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:47:39.947289+00
e982d2af-653d-49f0-9733-8ec47f07c54f	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:47:46.615249+00
1526c27a-de8b-47bd-bfc9-bdadb903a2d7	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:47:54.634106+00
a24c3b99-faae-41f6-bcc9-223f8777598a	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:48:02.636745+00
c5dfc1cf-b0c9-4ebf-b76c-aacf21b6bca8	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:48:10.689113+00
f232549e-5ebc-457b-ad87-b00204da85d3	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Looks like a good match based on description.	web-ui	2025-11-13 08:48:28.206887+00
edc49c0c-54dd-4eb1-9a24-88c9c41643dc	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-13 08:48:45.76894+00
8c730c19-0796-481e-8854-110f0772d6b3	14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	83.87096774193549	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-13 08:48:54.368974+00
4e653049-b9f3-420c-acf2-f9d7726f7b4c	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Match looks good, vendor note acknowledged.	web-ui	2025-11-13 08:50:18.973902+00
db41f6ba-9e67-4657-9f51-1581a4cfd73d	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: Match looks good, vendor note acknowledged.	web-ui	2025-11-13 08:50:45.495264+00
2695ff6d-5e98-441c-9aa0-716a4f336816	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: hi	web-ui	2025-11-13 18:48:59.558523+00
2a32b729-078e-4ac4-89d2-b1ec0020ff25	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: ;km;kn;	web-ui	2025-11-13 22:50:25.552972+00
6c665c24-5324-4e25-8221-b61fdc992716	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	86.23853211009174	review_ui	auto-accepted	Manual approval via review UI: kjhiu	web-ui	2025-11-13 23:22:48.153407+00
36d897a9-9d11-4002-b531-d9da3109b438	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	100	mapping_memory	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-13 23:23:40.728717+00
39b63e54-ebfc-4c3f-b705-3008dbe797ed	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	80	fuzzy_match	manual-review	Manual review required: confidence 80.0% < 85%; flags: VendorNote	web-ui	2025-11-13 23:23:40.735104+00
f4782a92-9792-4e0e-bef6-0b1fced30ac7	0166a311-ebc0-4bde-8ec9-d6c11e0b4362	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-13 23:23:40.737843+00
f04a692e-5cbd-4ae4-9156-3e6beb037ea4	14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-13 23:23:40.739519+00
cf647796-6864-4e50-9fec-8d12fb7d47a0	7c1e6a87-9bf7-4207-829d-5d8e2a65c8b2	13fbd16a-21ad-4117-9911-fafdb9d51174	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-13 23:23:40.7413+00
526299e9-3c67-44a0-8613-7d62610928f1	312f941f-59d0-4ceb-b6c2-4c004e47c6b0	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.743206+00
befcb4f4-8867-461f-a35b-e3888aa17fdb	d78382fe-7b65-4628-8639-9dd790efe7be	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.745015+00
795a87f3-7896-4a7c-958c-cbd8c61861e0	b2e1e9d1-c1f5-4a4f-827b-86127eef832f	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.746735+00
11b775fd-26a1-424b-ba0d-0ac8b1d7a786	35c7ab47-1103-4e1d-b416-d0be382e3aee	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.748263+00
6ea17148-b97e-42e6-8958-d7f8ec11be04	b17a7bb9-d15a-46d8-a9da-f83a2d98b93b	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.749755+00
eb880917-dd53-4d7e-8de5-81d294f4e0c0	e017e453-504d-40c5-a10c-452b8076fc97	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.75164+00
bf309d70-b596-40c9-93b2-6352e2c85c0f	3cac436a-2d8f-4ad0-bb48-6e91484ba877	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.753264+00
3295dbec-c99b-4832-9263-83508ba2f82f	d27082cd-7dbf-4e86-b215-10b15358f0f6	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.754984+00
b6b5731a-2dba-4cff-80e7-cc92765752ac	23844685-c033-4532-ab11-fa2aa8fa9945	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.756284+00
6b0cf704-c549-49c8-8932-841645dbb733	04a2c06f-40ac-4de2-a442-832ea8b90502	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.75775+00
58690b0a-104e-4c6b-a52b-19729f04bad3	d7987189-bbc8-44e3-b152-f293552d679a	da1c9a43-903d-40e8-895d-f376cc2fba6c	100	mapping_memory	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-13 23:23:40.759206+00
5e69cb5b-8fb7-43ff-8449-e8c239095c06	7be0d480-6f33-4162-9ddf-cfd4a1bc6338	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.761267+00
0cb8a9c4-f956-46a5-95be-f3510d44cc5d	6f1dbed6-1978-4b0e-895a-8c90fc961288	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.762544+00
48090e7f-f93e-4867-b604-7e10eb2e4f42	6573c446-39f8-4732-ba98-8553843728ad	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.76368+00
bbf74bea-6286-4d9a-a146-9fe3ac3a21ab	6a2c9293-e82d-4ace-86f8-7150b05a9715	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.765105+00
88dc416f-9891-4259-b33e-4ec6557cff52	070279bb-4a76-4c9c-8577-64a7758937c4	2321d513-8ed6-4ecf-8966-9145e9714e1f	100	mapping_memory	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-13 23:23:40.766463+00
4f193a9d-f224-403a-9f89-536a325312c2	7f721c79-9d6f-426d-ad1e-d98af036f00e	92aa4216-c788-4836-8e30-c2c7c988c3d3	80	fuzzy_match	manual-review	Manual review required: confidence 80.0% < 85%; flags: VendorNote	web-ui	2025-11-13 23:23:40.768989+00
b78bb074-a01d-4930-ad4c-8bd7a10b0d23	0ec08269-9419-4ae3-9d7f-595d3a090213	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-13 23:23:40.770755+00
74cd3a8c-ea4f-4bef-b873-47b46c3c1485	cb3c7b0f-465b-4d1c-9ef7-ca5b45aa987f	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-13 23:23:40.77184+00
996561e4-babe-488c-8f40-0c18e2c583b4	3c5e1ef3-323a-456e-a5b8-398df800f414	13fbd16a-21ad-4117-9911-fafdb9d51174	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	web-ui	2025-11-13 23:23:40.772887+00
81bfc4b9-2cb0-4865-950d-5f3d49c5c869	feddacad-7bfd-4407-a7f4-d92d8d67de95	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.774002+00
d53befe9-9134-40b1-90b6-ac5c55a2be62	5f02fa33-36c9-4445-bdd1-367e80e8277b	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.775122+00
dfda4732-ade5-4b07-acd5-1395dab55d0d	f04b7ec2-8b5a-42fc-87df-9ac455de5943	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.776621+00
83370ab5-93ec-4297-9d10-7ffd3ad7a740	1407d6ad-f8df-4512-af46-86b7b2579f33	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.777959+00
e7984e8b-33fd-4022-9c77-0163d2c3983d	7248e810-72e5-45ca-a756-6dfa08e64692	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.779183+00
b4d2215e-24d8-4946-8e26-ad1550aa2c9e	7d30bc21-5d47-4bbf-9b23-406ee50345d0	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.780336+00
4fa92385-3053-44f1-9d7a-0a2f8a374171	edb0a01b-6d84-444a-bc49-bfd9cc2094b4	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.781508+00
e9c74d5d-4021-41e4-a3e3-22d29cb99ec4	1d2e4506-2aa4-4c1b-a02c-082a058cae7d	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.782774+00
14249ee5-f838-4740-8ea8-4d527739937e	517f045b-fd64-4a80-9bce-462c4b1cf069	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.783917+00
71acac5c-1c77-4438-939e-ce55bb8ab255	fedb546b-35b3-422c-ad21-a6978ee7a55b	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.78511+00
3d4decd8-29de-4f4b-8deb-f39d2a1f5d50	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	100	mapping_memory	manual-review	Manual review required: flags: VendorNote	web-ui	2025-11-13 23:23:40.786403+00
6a5e7b9d-5824-4c32-aeca-3c971bcc1052	a2bde469-62b9-4f10-9d5f-050ad47f0420	\N	0	fuzzy_match	rejected	No candidates scored >= 70	web-ui	2025-11-13 23:23:40.787996+00
ce3362b4-5151-4031-bcc0-102624feacf8	6839a697-1e0f-4e9f-817b-f6b5cd9dbb36	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.789469+00
b77f6c76-5f0d-418c-bc85-a9ab5a11df89	ab4bec92-c0e9-4b5a-8b73-b5ee8f7f5e35	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.790613+00
fd87aa29-e2df-430d-bdb1-8728bf438daa	ac03e065-3b83-44f3-a4cc-6b23dd3d0364	\N	0	fuzzy_match	rejected	No candidates found after classification blocking	web-ui	2025-11-13 23:23:40.79167+00
51b7dbc3-78fd-430e-97df-6c666db5da13	14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	83.87096774193549	review_ui	auto-accepted	Manual approval via review UI	web-ui	2025-11-14 22:00:09.161709+00
09bd50e7-e50d-457c-a11d-a60e22fc4371	14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	83.87096774193549	review_ui	auto-accepted	Manual approval via review UI: ,mnbljn	web-ui	2025-11-14 22:00:12.403011+00
d388ab0f-f477-4933-8a0f-cdab49c32609	511b5903-a323-4485-a7fc-865f5ebd466d	2321d513-8ed6-4ecf-8966-9145e9714e1f	100	mapping_memory	manual-review	Manual review required: advisory flags: VendorNote	cli	2025-11-14 22:03:32.451412+00
77de67de-71ae-47dc-90cb-c94d5a5527a6	564ff7c9-9ffd-4188-b791-ac3cccbdf37b	92aa4216-c788-4836-8e30-c2c7c988c3d3	80	fuzzy_match	manual-review	Manual review required: confidence 80.0% < 85%; advisory flags: VendorNote	cli	2025-11-14 22:03:32.458728+00
5c2d5fe6-1713-47b0-9cac-28b2e1528016	0166a311-ebc0-4bde-8ec9-d6c11e0b4362	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli	2025-11-14 22:03:32.461459+00
885646bc-5bfb-48db-af17-a45b038b6552	14d6ccf8-7e05-4180-94d1-a8123f5e1bd4	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli	2025-11-14 22:03:32.463041+00
95c36820-8cd0-45d0-8072-1a4d60dded3b	7c1e6a87-9bf7-4207-829d-5d8e2a65c8b2	13fbd16a-21ad-4117-9911-fafdb9d51174	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli	2025-11-14 22:03:32.464494+00
5bf79f01-e386-4130-91ca-ed6e9b5960b2	312f941f-59d0-4ceb-b6c2-4c004e47c6b0	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.466179+00
a8d43f6a-7a99-4a7d-82db-f1d63add2a7c	d78382fe-7b65-4628-8639-9dd790efe7be	0f177c58-7717-4dc9-87ac-1db888db1e13	70.2127659574468	fuzzy_match	manual-review	Manual review required: confidence 70.2% < 85%; CRITICAL flags: Class Mismatch, Classification Mismatch	cli	2025-11-14 22:03:32.469092+00
f95ed7a3-0547-43a2-9244-45faece9ac2c	b2e1e9d1-c1f5-4a4f-827b-86127eef832f	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.472293+00
1baeb119-6c93-4fc1-ade4-96efe5268d65	35c7ab47-1103-4e1d-b416-d0be382e3aee	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.474236+00
a05859f8-7833-4a5d-8d2e-dfc09f6a78ff	b17a7bb9-d15a-46d8-a9da-f83a2d98b93b	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.475986+00
31ce7c3b-6697-4006-9f8e-52f5c0650656	e017e453-504d-40c5-a10c-452b8076fc97	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.477791+00
690eaa99-0f04-4d01-b53b-2f16616a4738	3cac436a-2d8f-4ad0-bb48-6e91484ba877	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.479348+00
781c768d-143d-40e6-8cc2-55a14ebd28d6	d27082cd-7dbf-4e86-b215-10b15358f0f6	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.481033+00
52480a2d-4b6f-476c-873e-13d8a58cb1ce	23844685-c033-4532-ab11-fa2aa8fa9945	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.483272+00
8309a1e5-1294-4541-bdb3-6ae7b3eed9c2	04a2c06f-40ac-4de2-a442-832ea8b90502	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.485387+00
18069180-bf7c-44f2-a962-8c3101acae7b	d7987189-bbc8-44e3-b152-f293552d679a	da1c9a43-903d-40e8-895d-f376cc2fba6c	100	mapping_memory	manual-review	Manual review required: advisory flags: VendorNote	cli	2025-11-14 22:03:32.487003+00
eb3e316f-143b-4150-9211-0facf6b749c6	7be0d480-6f33-4162-9ddf-cfd4a1bc6338	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.489181+00
d3a854e9-b7c9-42c1-8741-abd7b0b7dece	6f1dbed6-1978-4b0e-895a-8c90fc961288	10aa1b09-881c-4119-945c-3b7abd6a9405	97.5	fuzzy_match	manual-review	Manual review required: CRITICAL flags: Class Mismatch, Classification Mismatch	cli	2025-11-14 22:03:32.4912+00
d4352073-2b1f-4275-a3ba-db8d88ccd757	6573c446-39f8-4732-ba98-8553843728ad	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.494105+00
ea981191-8d2c-4589-9a80-a8ef5f581d43	6a2c9293-e82d-4ace-86f8-7150b05a9715	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.496398+00
4b3ac93e-126d-4bd0-b692-3baae3a8d7e5	070279bb-4a76-4c9c-8577-64a7758937c4	2321d513-8ed6-4ecf-8966-9145e9714e1f	100	mapping_memory	manual-review	Manual review required: advisory flags: VendorNote	cli	2025-11-14 22:03:32.497975+00
ca06fc8a-c0b5-43a2-afb5-0618bc51d33e	7f721c79-9d6f-426d-ad1e-d98af036f00e	92aa4216-c788-4836-8e30-c2c7c988c3d3	80	fuzzy_match	manual-review	Manual review required: confidence 80.0% < 85%; advisory flags: VendorNote	cli	2025-11-14 22:03:32.500464+00
a3b12be4-61b9-43d2-8fa1-5676dbfba27d	0ec08269-9419-4ae3-9d7f-595d3a090213	bc9b8c90-3d08-4c61-88a7-394e8ca69fce	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli	2025-11-14 22:03:32.50225+00
c7d741b5-6032-46f9-84f7-074c02112036	cb3c7b0f-465b-4d1c-9ef7-ca5b45aa987f	0d59dc06-7a41-4604-99f8-b552dbd2f8f7	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli	2025-11-14 22:03:32.503767+00
12d1cf0d-b22d-4cb6-99b0-bb376d117f5b	3c5e1ef3-323a-456e-a5b8-398df800f414	13fbd16a-21ad-4117-9911-fafdb9d51174	100	mapping_memory	auto-accepted	High confidence (100.0%), no flags, via mapping memory	cli	2025-11-14 22:03:32.505224+00
0f7f9a33-ac3a-455b-95ad-98f554cbf221	feddacad-7bfd-4407-a7f4-d92d8d67de95	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.506697+00
197387a5-61cf-414e-ba36-8ac5a0def6bf	5f02fa33-36c9-4445-bdd1-367e80e8277b	0f177c58-7717-4dc9-87ac-1db888db1e13	70.2127659574468	fuzzy_match	manual-review	Manual review required: confidence 70.2% < 85%; CRITICAL flags: Class Mismatch, Classification Mismatch	cli	2025-11-14 22:03:32.508649+00
0bdf3412-72ee-450d-8505-2efe3f146745	f04b7ec2-8b5a-42fc-87df-9ac455de5943	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.510718+00
29489981-028c-4312-8de7-01a567b5f1ff	1407d6ad-f8df-4512-af46-86b7b2579f33	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.513454+00
93d01298-0aeb-46b7-b040-6de78d790da3	7248e810-72e5-45ca-a756-6dfa08e64692	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.514996+00
5bfbf08f-3f5e-4629-8cd6-162cbee32492	7d30bc21-5d47-4bbf-9b23-406ee50345d0	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.516531+00
c917d054-169c-4a27-8af4-10bc422b88a8	edb0a01b-6d84-444a-bc49-bfd9cc2094b4	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.518078+00
e493060a-bcbe-42ec-9f6f-cfd0944f5bf8	1d2e4506-2aa4-4c1b-a02c-082a058cae7d	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.519606+00
e226466c-cb8a-4fb3-9e36-a92427f9cf76	517f045b-fd64-4a80-9bce-462c4b1cf069	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.521501+00
53fb2f84-4d06-4f73-a65d-3ab96e0d7fd7	fedb546b-35b3-422c-ad21-a6978ee7a55b	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.523699+00
acef4b27-a011-4875-b45b-03c4df63fd7e	1335170f-9dfd-4ac5-be84-67d83640a1df	da1c9a43-903d-40e8-895d-f376cc2fba6c	100	mapping_memory	manual-review	Manual review required: advisory flags: VendorNote	cli	2025-11-14 22:03:32.52508+00
b75088fd-2585-4685-ab74-5884967c220b	a2bde469-62b9-4f10-9d5f-050ad47f0420	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.527097+00
8c52ee6f-dad5-46ca-bd86-4fcedcbe4ed2	6839a697-1e0f-4e9f-817b-f6b5cd9dbb36	10aa1b09-881c-4119-945c-3b7abd6a9405	97.5	fuzzy_match	manual-review	Manual review required: CRITICAL flags: Class Mismatch, Classification Mismatch	cli	2025-11-14 22:03:32.529203+00
fe350e48-12ff-4608-a5f3-97e5987c1545	ab4bec92-c0e9-4b5a-8b73-b5ee8f7f5e35	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.532136+00
aab61f52-f0c2-4fa4-b20d-a3dc17700307	ac03e065-3b83-44f3-a4cc-6b23dd3d0364	\N	0	fuzzy_match	rejected	No candidates scored >= 70	cli	2025-11-14 22:03:32.534089+00
\.


--
-- Data for Name: price_items; Type: TABLE DATA; Schema: public; Owner: bimcalc
--

COPY public.price_items (id, classification_code, vendor_id, sku, description, unit, unit_price, currency, vat_rate, width_mm, height_mm, dn_mm, angle_deg, material, last_updated, vendor_note, attributes, created_at, item_code, region, source_name, source_currency, original_effective_date, valid_from, valid_to, is_current, org_id) FROM stdin;
125db1c0-47de-4e91-bb4c-fb10bc46a397	2650	default	VENDOR-CT-001	Ladder	ea	45.50	EUR	\N	200	\N	\N	\N	\N	\N	CMM: L-ELB90-W200-D50-GALV	{}	2025-11-08 17:21:28.074444+00	VENDOR-CT-001	UK	legacy_migration	EUR	\N	2025-11-08 17:21:28.074444+00	2025-11-08 17:31:46.79822+00	f	default
2321d513-8ed6-4ecf-8966-9145e9714e1f	2650	acme-electric	CT-L-200-90-GALV	Cable Tray Ladder Elbow 90deg 200x50 Galvanized	ea	45.50	EUR	0.23	200	50	\N	\N	Galvanized	\N	Standard stock item	{}	2025-11-08 17:27:11.028544+00	CT-L-200-90-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
92aa4216-c788-4836-8e30-c2c7c988c3d3	2650	acme-electric	CT-L-200-00-GALV	Cable Tray Ladder Straight 200x50 Galvanized	ea	32.00	EUR	0.23	200	50	\N	\N	Galvanized	\N	Per 3m length	{}	2025-11-08 17:27:11.028544+00	CT-L-200-00-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
bc9b8c90-3d08-4c61-88a7-394e8ca69fce	2650	acme-electric	CT-L-300-45-GALV	Cable Tray Ladder Elbow 45deg 300x50 Galvanized	ea	52.00	EUR	0.23	300	50	\N	45	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	CT-L-300-45-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
0d59dc06-7a41-4604-99f8-b552dbd2f8f7	2650	acme-electric	CT-L-200-TEE-GALV	Cable Tray Ladder Tee 200x50 Galvanized	ea	48.00	EUR	0.23	200	50	\N	\N	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	CT-L-200-TEE-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
13fbd16a-21ad-4117-9911-fafdb9d51174	2650	acme-electric	CT-L-300-200-RED	Cable Tray Ladder Reducer 300x50-200x50	ea	38.50	EUR	0.23	300	50	\N	\N	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	CT-L-300-200-RED	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
e3df7942-fc6c-421d-b596-69ae0f6865ae	2211	acme-electric	PIPE-DN50-90-GALV	Pipe Elbow 90deg DN50 Galvanized	ea	28.00	EUR	0.23	\N	\N	50	90	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	PIPE-DN50-90-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
0f177c58-7717-4dc9-87ac-1db888db1e13	2211	acme-electric	PIPE-DN50-00-GALV	Pipe Straight DN50 Galvanized	m	15.50	EUR	0.23	\N	\N	50	\N	Galvanized	\N	Per meter	{}	2025-11-08 17:27:11.028544+00	PIPE-DN50-00-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
3ea3c57e-a16d-4336-9e3b-aa26749098c4	2211	acme-electric	PIPE-DN100-90-GALV	Pipe Elbow 90deg DN100 Galvanized	ea	42.00	EUR	0.23	\N	\N	100	90	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	PIPE-DN100-90-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
af51e463-6401-429b-a272-b69bd64ed361	2211	acme-electric	PIPE-DN50-TEE-GALV	Pipe Tee DN50 Galvanized	ea	32.00	EUR	0.23	\N	\N	50	\N	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	PIPE-DN50-TEE-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
1fb88b97-0d7c-4e36-b840-8a0e318087b1	2211	acme-electric	PIPE-DN50-45-GALV	Pipe Elbow 45deg DN50 Galvanized	ea	26.00	EUR	0.23	\N	\N	50	45	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	PIPE-DN50-45-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
89fd556d-ec5e-481d-ab7b-a97f587c149d	2655	acme-electric	COND-25-90-PVC	Conduit Elbow 90deg 25mm PVC	ea	8.50	EUR	0.23	25	\N	\N	\N	PVC	\N	\N	{}	2025-11-08 17:27:11.028544+00	COND-25-90-PVC	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
f8e6dd64-da42-404f-b90b-691ab6b6d246	2655	acme-electric	COND-25-00-PVC	Conduit Straight 25mm PVC	ea	4.20	EUR	0.23	25	\N	\N	\N	PVC	\N	Per 3m length	{}	2025-11-08 17:27:11.028544+00	COND-25-00-PVC	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
3d9060a1-a737-4ed0-b845-4e574f98c5c8	2655	acme-electric	COND-25-COUP-PVC	Conduit Coupling 25mm PVC	ea	2.80	EUR	0.23	25	\N	\N	\N	PVC	\N	\N	{}	2025-11-08 17:27:11.028544+00	COND-25-COUP-PVC	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
a3d0e265-0d13-42e1-96c2-9da67a3a22e1	2342	acme-electric	DUCT-300-90-GALV	Duct Elbow 90deg 300x200 Galvanized	ea	68.00	EUR	0.23	300	200	\N	\N	Galvanized	\N	\N	{}	2025-11-08 17:27:11.028544+00	DUCT-300-90-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
da1c9a43-903d-40e8-895d-f376cc2fba6c	2650	acme-electric	CT-P-150-90-SS	Cable Tray Perforated Elbow 90deg 150x50 SS	ea	72.00	EUR	0.23	150	50	\N	\N	Stainless	\N	Premium material	{}	2025-11-08 17:27:11.028544+00	CT-P-150-90-SS	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
cdade4ea-f27d-445c-82bd-8ea101f6e9ac	2211	acme-electric	PIPE-DN32-90-CU	Pipe Elbow 90deg DN32 Copper Type K	ea	35.00	EUR	0.23	\N	\N	32	90	Copper	\N	\N	{}	2025-11-08 17:27:11.028544+00	PIPE-DN32-90-CU	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
10aa1b09-881c-4119-945c-3b7abd6a9405	2211	acme-electric	PIPE-DN32-00-CU	Pipe Straight DN32 Copper Type K	m	22.50	EUR	0.23	\N	\N	32	\N	Copper	\N	Per meter	{}	2025-11-08 17:27:11.028544+00	PIPE-DN32-00-CU	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
df40e787-f6f3-46db-a8f8-5e9c878735e4	2356	acme-electric	LIGHT-600-LED-40W	LED Panel 600x600 40W 4000K	ea	85.00	EUR	0.23	600	600	\N	\N	Aluminum	\N	5yr warranty	{}	2025-11-08 17:27:11.028544+00	LIGHT-600-LED-40W	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
f64b900b-c7fb-486f-940b-2b98d65e6057	2356	acme-electric	LIGHT-150-DL-12W	LED Downlight 150mm 12W 3000K	ea	42.00	EUR	0.23	150	\N	\N	\N	Aluminum	\N	IP44 rated	{}	2025-11-08 17:27:11.028544+00	LIGHT-150-DL-12W	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
397569d1-2bb2-4c6d-a8fe-eb7d751796b0	2650	default	VENDOR-CT-001	Ladder	ea	45.50	EUR	\N	200	\N	\N	\N	\N	\N	CMM: L-ELB90-W200-D50-GALV	{}	2025-11-08 17:31:46.79822+00	VENDOR-CT-001	UK	legacy_migration	EUR	\N	2025-11-08 17:31:46.79822+00	\N	t	default
944ae630-a7cf-458b-b278-ce76ad1dccea	66	demo_vendor	DEMO-UK-CT-LAD	Cable Tray Ladder Type [UK]	m	85.00	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:52.996708+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-CT-LAD	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:52.996708+00	\N	t	default
260f37a7-3093-4d15-a002-6b8fc1589b93	66	demo_vendor	DEMO-UK-CB-90-200x50	Cable Tray Elbow 90° 200x50mm [UK]	ea	42.50	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:52.999525+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-CB-90-200x50	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:52.999525+00	\N	t	default
c8c61726-1457-4142-8139-f17c1615442d	66	demo_vendor	DEMO-UK-CB-45-300x50	Cable Tray Elbow 45° 300x50mm [UK]	ea	38.75	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.000784+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-CB-45-300x50	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.000784+00	\N	t	default
7813ff14-53e5-41da-9764-2269505c9865	2342	acme-electric	DUCT-300-00-GALV	Duct Straight 300x200 Galvanized	ea	45.00	EUR	0.23	300	200	\N	\N	Galvanized	\N	Per 1.2m	{}	2025-11-08 17:27:11.028544+00	DUCT-300-00-GALV	UK	legacy_migration	EUR	\N	2025-11-08 17:27:11.028544+00	\N	t	default
590097cf-5541-456d-a2dd-0c14672d577e	66	demo_vendor	DEMO-UK-TEE-200x50	Cable Tray Tee 200x50mm [UK]	ea	55.00	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.001905+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-TEE-200x50	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.001905+00	\N	t	default
454e6728-4fea-4672-9917-d99d9f265a5f	66	demo_vendor	DEMO-UK-CROSS-200x50	Cable Tray Cross 200x50mm [UK]	ea	68.00	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.002842+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-CROSS-200x50	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.002842+00	\N	t	default
2f4c23a8-eece-4fc5-8e19-a59f1d8df284	66	demo_vendor	DEMO-UK-REDUCER-300-200	Cable Tray Reducer 300-200mm [UK]	ea	32.50	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.106718+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-REDUCER-300-200	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.106718+00	\N	t	default
7a8efe82-7a03-4ca7-aa84-a14bdc0ecd10	66	demo_vendor	DEMO-UK-CP-200x50	Cable Tray Cover Plate 200x50mm [UK]	m	18.00	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.108235+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-CP-200x50	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.108235+00	\N	t	default
50ee2bbf-9a78-4bd8-8b75-111b03abba5b	66	demo_vendor	DEMO-UK-SUSP-ADJ	Adjustable Cable Tray Suspension [UK]	ea	12.50	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.109837+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-SUSP-ADJ	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.109837+00	\N	t	default
a4305cbb-8f47-4dae-a190-f332e8430766	66	demo_vendor	DEMO-UK-COUPLER-200	Cable Tray Coupler 200mm [UK]	ea	8.75	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.111276+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-COUPLER-200	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.111276+00	\N	t	default
6520fef9-91ca-40fa-8649-d8795faaef4b	2215	test_vendor	ELBOW-001	Cable Tray Elbow 90deg 200x50mm Galvanized	ea	52.00	EUR	\N	200	50	\N	\N	galvanized	2025-11-14 08:01:53.579406+00	\N	{}	2025-11-13 23:20:54.699505+00	ELBOW-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.700943+00	\N	t	default
e1ca9a0f-42ad-4631-b2d5-77dadb863136	2215	test_vendor	ELBOW-002	Cable Tray Elbow 45deg 200x50mm Galvanized	ea	42.00	EUR	\N	200	50	\N	\N	galvanized	2025-11-14 08:01:53.581543+00	\N	{}	2025-11-13 23:20:54.699505+00	ELBOW-002	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.705622+00	\N	t	default
cd51981e-1b06-47e3-9716-79a6c4844de5	2215	test_vendor	TRAY-001	Cable Tray Straight 3m 200x50mm Galvanized	ea	89.99	EUR	\N	200	50	\N	\N	galvanized	2025-11-14 08:01:53.582912+00	\N	{}	2025-11-13 23:20:54.699505+00	TRAY-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.707197+00	\N	t	default
384fd6f5-de5d-4a35-a7e4-366f8a91a3f1	2215	test_vendor	BRACKET-001	Cable Tray Support Bracket Heavy Duty	ea	12.50	EUR	\N	\N	\N	\N	\N	galvanized	2025-11-14 08:01:53.584345+00	\N	{}	2025-11-13 23:20:54.699505+00	BRACKET-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.708859+00	\N	t	default
f0a8ac38-5899-48da-8f5b-04c04dcb2deb	2216	test_vendor	FITTING-001	Conduit Elbow 90deg 25mm	ea	3.75	EUR	\N	25	\N	\N	\N	pvc	2025-11-14 08:01:53.585881+00	\N	{}	2025-11-13 23:20:54.699505+00	FITTING-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.710268+00	\N	t	default
dafee250-cb6b-40e1-b743-f777dc1e4c2b	2216	test_vendor	CONDUIT-001	Conduit Straight 3m 25mm	m	8.50	EUR	\N	25	\N	\N	\N	pvc	2025-11-14 08:01:53.586967+00	\N	{}	2025-11-13 23:20:54.699505+00	CONDUIT-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.711732+00	\N	t	default
d41a5f5b-ffa3-4b30-85c4-0aedc6276aee	2320	test_vendor	LIGHT-001	LED Panel 60x60cm 40W 4000K	ea	125.00	EUR	\N	600	600	\N	\N	\N	2025-11-14 08:01:53.588026+00	\N	{}	2025-11-13 23:20:54.699505+00	LIGHT-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.713098+00	\N	t	default
94227ed1-b052-4407-b85c-849024ac31c4	2340	test_vendor	SWITCH-001	Light Switch Single Gang White	ea	8.90	EUR	\N	\N	\N	\N	\N	plastic	2025-11-14 08:01:53.589051+00	\N	{}	2025-11-13 23:20:54.699505+00	SWITCH-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.714278+00	\N	t	default
0c8e7379-0f3b-47e0-8b7d-3427805ccbfa	2340	test_vendor	SOCKET-001	Power Socket Double Gang White	ea	12.50	EUR	\N	\N	\N	\N	\N	plastic	2025-11-14 08:01:53.590031+00	\N	{}	2025-11-13 23:20:54.699505+00	SOCKET-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.715422+00	\N	t	default
ac18cbdb-148c-4063-8266-2e79f426c8fd	2210	test_vendor	CABLE-001	Power Cable 3x2.5mm NYM-J	m	2.85	EUR	\N	\N	\N	\N	\N	copper	2025-11-14 08:01:53.59094+00	\N	{}	2025-11-13 23:20:54.699505+00	CABLE-001	UK	test_prices_local	EUR	\N	2025-11-13 23:20:54.716734+00	\N	t	default
9057f9ad-b61f-4b35-aaeb-c26d61dd4b06	66	demo_vendor	DEMO-UK-ENDCAP-200	Cable Tray End Cap 200mm [UK]	ea	5.50	GBP	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.112302+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-UK-ENDCAP-200	UK	demo_api_multi_region	GBP	\N	2025-11-14 08:01:53.112302+00	\N	t	default
a0d331cd-16a7-4f7c-b1c2-6d756f278573	66	demo_vendor	DEMO-IE-CT-LAD	Cable Tray Ladder Type [IE]	m	92.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.217485+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-CT-LAD	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.217485+00	\N	t	default
5ac177aa-6139-4c9d-8a8a-212375787b2f	66	demo_vendor	DEMO-IE-CB-90-200x50	Cable Tray Elbow 90° 200x50mm [IE]	ea	46.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.219669+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-CB-90-200x50	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.219669+00	\N	t	default
28e9bd93-9424-4fa1-ba31-026b9c8e79a2	66	demo_vendor	DEMO-IE-CB-45-300x50	Cable Tray Elbow 45° 300x50mm [IE]	ea	42.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.221264+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-CB-45-300x50	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.221264+00	\N	t	default
e7833699-53c9-4aea-9b48-4db8a9a2cfeb	66	demo_vendor	DEMO-IE-TEE-200x50	Cable Tray Tee 200x50mm [IE]	ea	59.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.222767+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-TEE-200x50	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.222767+00	\N	t	default
67a1f991-6846-47a3-9e6e-7e9a1802d97c	66	demo_vendor	DEMO-IE-CROSS-200x50	Cable Tray Cross 200x50mm [IE]	ea	73.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.224363+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-CROSS-200x50	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.224363+00	\N	t	default
d13323d2-e813-4f53-a52e-10bc84c2c336	66	demo_vendor	DEMO-IE-REDUCER-300-200	Cable Tray Reducer 300-200mm [IE]	ea	35.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.329691+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-REDUCER-300-200	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.329691+00	\N	t	default
cb4d89d8-a0b6-4518-9f9b-08109f4590a8	66	demo_vendor	DEMO-IE-CP-200x50	Cable Tray Cover Plate 200x50mm [IE]	m	19.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.333143+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-CP-200x50	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.333143+00	\N	t	default
6ca9c487-ed8f-4724-891d-f46f28a9de57	66	demo_vendor	DEMO-IE-SUSP-ADJ	Adjustable Cable Tray Suspension [IE]	ea	13.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.335938+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-SUSP-ADJ	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.335938+00	\N	t	default
09dda8c2-bdfa-49ba-afcc-cc29a9b470be	66	demo_vendor	DEMO-IE-COUPLER-200	Cable Tray Coupler 200mm [IE]	ea	9.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.337509+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-COUPLER-200	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.337509+00	\N	t	default
20c53a04-d8df-4147-bee4-955b5b7ca4f3	66	demo_vendor	DEMO-IE-ENDCAP-200	Cable Tray End Cap 200mm [IE]	ea	6.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.339067+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-IE-ENDCAP-200	IE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.339067+00	\N	t	default
2f53d616-5564-40cf-8d9a-6c79caf7d5f4	66	demo_vendor	DEMO-DE-CT-LAD	Cable Tray Ladder Type [DE]	m	88.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.445125+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-CT-LAD	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.445125+00	\N	t	default
8cfb0fe9-b72c-42fe-b2ff-5d6027364a4d	66	demo_vendor	DEMO-DE-CB-90-200x50	Cable Tray Elbow 90° 200x50mm [DE]	ea	44.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.448985+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-CB-90-200x50	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.448985+00	\N	t	default
380a14a8-35ea-4b3a-a4b9-344096a855e7	66	demo_vendor	DEMO-DE-CB-45-300x50	Cable Tray Elbow 45° 300x50mm [DE]	ea	40.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.450918+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-CB-45-300x50	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.450918+00	\N	t	default
f6456b37-bd05-46a5-b19c-6d9f954a365a	66	demo_vendor	DEMO-DE-TEE-200x50	Cable Tray Tee 200x50mm [DE]	ea	57.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.452658+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-TEE-200x50	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.452658+00	\N	t	default
e63a5617-a644-40e0-8106-d4e8d75219f0	66	demo_vendor	DEMO-DE-CROSS-200x50	Cable Tray Cross 200x50mm [DE]	ea	70.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.454168+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-CROSS-200x50	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.454168+00	\N	t	default
6a2152d0-9f01-46e0-8f38-0384962c9007	66	demo_vendor	DEMO-DE-REDUCER-300-200	Cable Tray Reducer 300-200mm [DE]	ea	33.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.561906+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-REDUCER-300-200	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.561906+00	\N	t	default
25fa4122-37b4-40e8-adf0-29eda9a7cfc4	66	demo_vendor	DEMO-DE-CP-200x50	Cable Tray Cover Plate 200x50mm [DE]	m	18.50	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.565236+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-CP-200x50	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.565236+00	\N	t	default
6f2411be-84a6-4aef-bd10-860ce6f3864c	66	demo_vendor	DEMO-DE-SUSP-ADJ	Adjustable Cable Tray Suspension [DE]	ea	13.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.567119+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-SUSP-ADJ	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.567119+00	\N	t	default
146906d2-e448-4873-8efc-dbd8263f85db	66	demo_vendor	DEMO-DE-COUPLER-200	Cable Tray Coupler 200mm [DE]	ea	9.00	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.568565+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-COUPLER-200	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.568565+00	\N	t	default
f7780584-c0de-4770-8cfe-fe2998af883c	66	demo_vendor	DEMO-DE-ENDCAP-200	Cable Tray End Cap 200mm [DE]	ea	5.75	EUR	\N	\N	\N	\N	\N	\N	2025-11-14 08:01:53.569774+00	\N	{}	2025-11-14 08:01:52.994975+00	DEMO-DE-ENDCAP-200	DE	demo_api_multi_region	EUR	\N	2025-11-14 08:01:53.569774+00	\N	t	default
\.


--
-- Name: data_sync_log data_sync_log_pkey; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.data_sync_log
    ADD CONSTRAINT data_sync_log_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: item_mapping item_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.item_mapping
    ADD CONSTRAINT item_mapping_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: match_flags match_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.match_flags
    ADD CONSTRAINT match_flags_pkey PRIMARY KEY (id);


--
-- Name: match_results match_results_pkey; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.match_results
    ADD CONSTRAINT match_results_pkey PRIMARY KEY (id);


--
-- Name: price_items price_items_pkey; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.price_items
    ADD CONSTRAINT price_items_pkey PRIMARY KEY (id);


--
-- Name: item_mapping uq_mapping_start; Type: CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.item_mapping
    ADD CONSTRAINT uq_mapping_start UNIQUE (org_id, canonical_key, start_ts);


--
-- Name: idx_flags_item; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_flags_item ON public.match_flags USING btree (item_id);


--
-- Name: idx_flags_match_result; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_flags_match_result ON public.match_flags USING btree (match_result_id);


--
-- Name: idx_flags_price; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_flags_price ON public.match_flags USING btree (price_item_id);


--
-- Name: idx_flags_severity; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_flags_severity ON public.match_flags USING btree (severity);


--
-- Name: idx_items_canonical; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_items_canonical ON public.items USING btree (canonical_key);


--
-- Name: idx_items_class; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_items_class ON public.items USING btree (classification_code);


--
-- Name: idx_mapping_active; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE UNIQUE INDEX idx_mapping_active ON public.item_mapping USING btree (org_id, canonical_key) WHERE (end_ts IS NULL);


--
-- Name: idx_mapping_temporal; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_mapping_temporal ON public.item_mapping USING btree (org_id, canonical_key, start_ts, end_ts);


--
-- Name: idx_price_active_unique; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE UNIQUE INDEX idx_price_active_unique ON public.price_items USING btree (item_code, region) WHERE (is_current = true);


--
-- Name: idx_price_class; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_price_class ON public.price_items USING btree (classification_code);


--
-- Name: idx_price_current; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_price_current ON public.price_items USING btree (item_code, region, is_current);


--
-- Name: idx_price_source; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_price_source ON public.price_items USING btree (source_name, last_updated);


--
-- Name: idx_price_temporal; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_price_temporal ON public.price_items USING btree (item_code, region, valid_from, valid_to);


--
-- Name: idx_sync_failures; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_sync_failures ON public.data_sync_log USING btree (status, run_timestamp);


--
-- Name: idx_sync_run; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_sync_run ON public.data_sync_log USING btree (run_timestamp, source_name);


--
-- Name: idx_sync_source_health; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX idx_sync_source_health ON public.data_sync_log USING btree (source_name, status, run_timestamp);


--
-- Name: ix_documents_doc_type; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_documents_doc_type ON public.documents USING btree (doc_type);


--
-- Name: ix_items_canonical_key; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_items_canonical_key ON public.items USING btree (canonical_key);


--
-- Name: ix_items_classification_code; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_items_classification_code ON public.items USING btree (classification_code);


--
-- Name: ix_items_org_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_items_org_id ON public.items USING btree (org_id);


--
-- Name: ix_items_project_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_items_project_id ON public.items USING btree (project_id);


--
-- Name: ix_match_flags_item_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_match_flags_item_id ON public.match_flags USING btree (item_id);


--
-- Name: ix_match_flags_match_result_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_match_flags_match_result_id ON public.match_flags USING btree (match_result_id);


--
-- Name: ix_match_flags_price_item_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_match_flags_price_item_id ON public.match_flags USING btree (price_item_id);


--
-- Name: ix_match_results_decision; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_match_results_decision ON public.match_results USING btree (decision);


--
-- Name: ix_match_results_item_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_match_results_item_id ON public.match_results USING btree (item_id);


--
-- Name: ix_match_results_price_item_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_match_results_price_item_id ON public.match_results USING btree (price_item_id);


--
-- Name: ix_price_items_classification_code; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_price_items_classification_code ON public.price_items USING btree (classification_code);


--
-- Name: ix_price_items_sku; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_price_items_sku ON public.price_items USING btree (sku);


--
-- Name: ix_price_items_vendor_id; Type: INDEX; Schema: public; Owner: bimcalc
--

CREATE INDEX ix_price_items_vendor_id ON public.price_items USING btree (vendor_id);


--
-- Name: match_flags match_flags_match_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bimcalc
--

ALTER TABLE ONLY public.match_flags
    ADD CONSTRAINT match_flags_match_result_id_fkey FOREIGN KEY (match_result_id) REFERENCES public.match_results(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict dpaxCSmugJdY0xRKd8dj6rb5UdJCj5lL0vyUKcBMfSQBx7xUTdAUAqHAVfRcf8U

